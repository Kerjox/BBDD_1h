/*
 01. Inner Joins
 Devuelve la información completa de todos las direcciones donde existen
 almacenes que hayan realizado alquileres de películas de clasificación NC-17
 en idioma INGLÉS. Mostrar la información de la dirección, el alquiler, y la película
 */

SELECT d.direccion, a2.id_alquiler, p.titulo FROM almacen a INNER JOIN direccion d
    on a.id_direccion = d.id_direccion INNER JOIN inventario i
        on a.id_almacen = i.id_almacen INNER JOIN alquiler a2
            on i.id_inventario = a2.id_inventario INNER JOIN pelicula p
                on i.id_pelicula = p.id_pelicula INNER JOIN idioma i2
                    on p.id_idioma = i2.id_idioma
WHERE p.clasificacion = 'NC-17' AND i2.nombre = 'English';

/*
 02. Outer Joins
Devuelve la información de todas las películas, junto con sus
 alquileres(hayan sido alquiladas, o no), y la información de la categoría,
 de todas las actrices de nombre JULIA. Si la película ha sido alquilada se
 mostrará una columna con el texto ALQUILADA y en caso contrario NO ALQUILADA.
 */

SELECT DISTINCT p.titulo, c.nombre FROM pelicula p INNER JOIN inventario i
    on p.id_pelicula = i.id_pelicula LEFT OUTER JOIN alquiler a
        on i.id_inventario = a.id_inventario INNER JOIN pelicula_categoria pc
            on p.id_pelicula = pc.id_pelicula INNER JOIN categoria c
                on pc.id_categoria = c.id_categoria

/*
 INDEX
Crea un índice de tipo FULL TEXT en la tabla direccion sobre los campos
 direccion y direccion2. Realiza después una búsqueda sobre este índice para
 encontrar todas las Avenue donde viva algún empleado. Deja indicada en la
 solución esta consulta de búsqueda.
 */

DROP INDEX IF EXISTS direcciones_index ON direccion;
CREATE FULLTEXT INDEX direcciones_index ON direccion (
    direccion, direccion2
    );

EXPLAIN SELECT e.nombre, d.direccion FROM empleado e INNER JOIN direccion d
    on e.id_direccion = d.id_direccion
WHERE direccion LIKE '%Avenue%';

/*
 04. STORED PROCEDURES
Crea una tabla llamada
 caracteristicas_especiales(id_pelicula integer unsigned, trailer boolean, comentarios boolean, behind_scenes boolean)
 y un procedimiento almacenado que leyendo la información de la tabla peliculas
 inserte en esta nueva tabla el identificador de cada película y activando o
 desactivando el booleano correspondiente de la tabla según la información contenida
 en la columna caracteristicas_especiales de la tabla peliculas.
Debes incorporar en la solución la consulta de creación de la tabla
 caracteristicas_especiales

caracteristicas_especiales:

 */

DROP TABLE IF EXISTS caracteristicas_especiales;
CREATE TABLE caracteristicas_especiales (
    id_pelicula INTEGER UNSIGNED,
    trailer BOOLEAN,
    comentarios BOOLEAN,
    behind_scenes BOOLEAN
);

DROP PROCEDURE IF EXISTS fill_caracteristicas_especiales;
DELIMITER $$
CREATE PROCEDURE fill_caracteristicas_especiales()
BEGIN

    DECLARE _behind_the_scenes BOOLEAN DEFAULT FALSE;
    DECLARE _commentaries BOOLEAN DEFAULT FALSE;
    DECLARE _trailers BOOLEAN DEFAULT FALSE;
    DECLARE caracteristicas VARCHAR(100);
    DECLARE _id_pelicula INT UNSIGNED;
    DECLARE done BOOLEAN DEFAULT FALSE;
    DECLARE caracteristicas_cur CURSOR FOR SELECT p.id_pelicula, p.caracteristicas_especiales FROM pelicula p;

    DECLARE CONTINUE HANDLER FOR SQLSTATE '02000'
        BEGIN
            SET done = TRUE;
        END ;

    OPEN caracteristicas_cur;
    loop1:LOOP

        /*SET _deleted_scenes = (SELECT p.caracteristicas_especiales FROM pelicula p WHERE p.caracteristicas_especiales LIKE '%Deleted Scenes%');*/
        SET _commentaries = FALSE;
        SET _trailers = FALSE;
        SET _behind_the_scenes = FALSE;


        FETCH caracteristicas_cur INTO _id_pelicula, caracteristicas;

        IF done THEN
            LEAVE loop1;
        END IF ;

        IF (FIND_IN_SET(caracteristicas, 'Commentaries')) THEN
           SET _commentaries = TRUE;
        END if ;

        IF (FIND_IN_SET(caracteristicas, 'Trailers')) THEN
           SET _trailers = TRUE;
        END if ;

        IF (FIND_IN_SET(caracteristicas, 'Behind the Scenes')) THEN
           SET _behind_the_scenes = TRUE;
        END if ;
        /*SELECT _id_pelicula, _trailers, _commentaries, _deleted_scenes;*/
        INSERT INTO caracteristicas_especiales VALUES (_id_pelicula, _trailers, _commentaries, _behind_the_scenes);
    END LOOP ;

    CLOSE caracteristicas_cur;
END $$
DELIMITER ;


CALL fill_caracteristicas_especiales();

/*
 Crea un procedimiento almacenado que nos permita dado el parámetro del distrito
 devuelve como parámetro de salida el número de clientes que están inactivos.
 Si ese parámetro es nulo mostraremos los clientes de cualquier distrito,
 además mostraremos en pantalla su dirección de correo electrónico.
 Además para todos estos usuarios cambiaremos su dirección de correo electrónico
 por una que sea inicial_del_nombre+tres_primeras_letras_del_apellido@salesianos.edu
 */

DROP PROCEDURE IF EXISTS distrito;
DELIMITER $$
CREATE PROCEDURE distrito(IN _distrito VARCHAR(20), OUT clientes_inativaos INT UNSIGNED)
BEGIN


    DECLARE _email VARCHAR(100);
    DECLARE _id_cliente INT UNSIGNED;
    DECLARE done BOOLEAN DEFAULT FALSE;
    DECLARE cur1 CURSOR FOR SELECT c.id_cliente FROM cliente c WHERE c.activo = 0;
    DECLARE CONTINUE HANDLER FOR SQLSTATE '02000'
        BEGIN
            SET done = TRUE;
        END ;


    IF _distrito IS NOT NULL THEN
        SET clientes_inativaos = (SELECT COUNT(c.nombre)
            FROM cliente c INNER JOIN direccion d
                on c.id_direccion = d.id_direccion
            WHERE d.distrito = _distrito AND c.activo = 0);
    ELSE
        OPEN cur1;
        SET clientes_inativaos = (SELECT COUNT(c.nombre)
            FROM cliente c
            WHERE c.activo = 0);

        SELECT c.nombre, c.email FROM cliente c WHERE c.activo = 0;

        loop1: loop
            FETCH cur1 INTO _id_cliente;
            IF done THEN
                LEAVE loop1;
            end if ;

            SET _email = (SELECT CONCAT(SUBSTR(c.nombre, 1, 1), SUBSTR(c.apellidos, 1, 3), '@salesianos.edu') FROM cliente c WHERE c.id_cliente = _id_cliente);
            UPDATE cliente SET email = _email WHERE cliente.id_cliente = _id_cliente;
        end loop ;
        CLOSE cur1;
    END IF ;

END $$
DELIMITER ;

CALL distrito(NULL, @clientes_inativaos);
SELECT @clientes_inativaos;

/*
 Crea un procedimiento que marque como usuarios inactivos a aquellos clientes
 con un alquiler pendiente de devolver, además crearemos una tabla llamada
 morosos en la que insertamos el identificador del cliente pendiente de
 devolver alguna película y su email, debes controlar el error de duplicate
 primary key al introducir la información en la tabla de morosos
morosos:
	id_cliente integer primary key,
	email varchar(50)

 */

DROP TABLE IF EXISTS morosos;
CREATE TABLE morosos (
    id_cliente integer primary key,
	email varchar(50)
);

DROP PROCEDURE IF EXISTS calc_morosos;
DELIMITER $$
CREATE PROCEDURE calc_morosos()
BEGIN

    DECLARE _email VARCHAR(100);
    DECLARE _id_cliente INT UNSIGNED;
    DECLARE done BOOLEAN DEFAULT FALSE;
    DECLARE cur1 CURSOR FOR SELECT c.id_cliente, c.email FROM cliente c INNER JOIN alquiler a
        ON c.id_cliente = a.id_cliente WHERE a.fecha_devolucion IS NULL ;
    DECLARE CONTINUE HANDLER FOR SQLSTATE '02000', 1062
        BEGIN
            SET done = TRUE;
        end ;

    OPEN cur1;
    loop1:LOOP

        FETCH cur1 INTO _id_cliente, _email;
        IF done THEN

            LEAVE loop1;
        end if ;

        INSERT INTO morosos VALUES (_id_cliente, _email);
    end loop ;
    CLOSE cur1;
end $$;

DELIMITER ;

CALL calc_morosos();
SELECT * FROM morosos;

/*
 FUNCTIONS
Crea una función llamada horas_metraje que dada una calificación de edad de
 la pelicula(clasificacion) y una dirección de calle de almacén nos diga el
 total de horas de metraje que existe de esa clasificación por edades de todos
 los almacenes de la dirección indicada.
 */

DROP FUNCTION IF EXISTS horas_metraje;
DELIMITER $$
CREATE FUNCTION horas_metraje(_clasificacion VARCHAR(10), _direccion VARCHAR(100))
RETURNS INT UNSIGNED
BEGIN

    RETURN (SELECT SUM(p.duracion) FROM pelicula p
        INNER JOIN inventario i on p.id_pelicula = i.id_pelicula
        INNER JOIN almacen a on i.id_almacen = a.id_almacen
        INNER JOIN direccion d on a.id_direccion = d.id_direccion
        WHERE d.direccion = _direccion);

end $$
DELIMITER ;
SELECT horas_metraje('NC-17', '47 MySakila Drive')


/*
 Crea una función que dado un id_almacen, una duración máxima y una
 duracion minima nos devuelva el total del (replacement_cost - rental_rate)
 de TODAS las películas de ese almacén con la duración indicada.
 */

DROP FUNCTION IF EXISTS coste;
DELIMITER $$
CREATE FUNCTION coste(_id_almacen INT UNSIGNED, _min INT UNSIGNED, _max INT UNSIGNED)
RETURNS INT UNSIGNED
BEGIN

    RETURN (SELECT SUM(p.replacement_cost - p.rental_rate) FROM pelicula p
        INNER JOIN inventario i on p.id_pelicula = i.id_pelicula
        INNER JOIN almacen a on i.id_almacen = a.id_almacen
        WHERE a.id_almacen = _id_almacen AND p.duracion BETWEEN _min AND _max);

end $$
DELIMITER ;

/*
 TRIGGERS
Crea un trigger que cuando se borre un jefe se reasigne los empleados que tenía
 por debajo a otros jefes(no empleados). Esta re-asignacion de jefe se realizará
 de manera aleatoria siempre y cuando el jefe nuevo al que se reasignan los empleados
 no tenga más de dos empleados asignados previamente.
 */

/*

 Crea un trigger para que cuando un empleado pase de estar activo a inactivo,
 se deberá borrar el campo password de la tabla y se guardará en una tabla
 llamada empleado_log( nombre_apellido varchar(100), old_pass varchar(50) )
 el nombre y apellido del empleado y la contraseña vieja que tenía, además
 este trigger cada vez que se produzca una modificación de la tabla empleado
 deberá modificar la columna ultima_actualizacion insertando en ella la fecha actual.
 */

DROP TABLE IF EXISTS empleado_log;
CREATE TABLE empleado_log(
    nombre_apellido varchar(100),
    old_pass varchar(50)
);

DROP TRIGGER IF EXISTS a;
DELIMITER $$
CREATE TRIGGER a
    BEFORE UPDATE
    ON empleado
    FOR EACH ROW
BEGIN

    SET NEW.password = NULL;
    SET NEW.ultima_actualizacion = NOW();
    INSERT INTO empleado_log VALUES (CONCAT(NEW.nombre, NEW.apellidos), OLD.password);

end $$
DELIMITER ;

